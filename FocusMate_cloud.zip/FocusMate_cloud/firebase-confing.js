const firebaseConfig = {
  apiKey: "AIzaSyARGxsqLIP7P8rpYBrU-LWvxLeB3HDL6",
  authDomain: "studio-117453895-53ff3.firebaseapp.com",
  projectId: "studio-117453895-53ff3",
  storageBucket: "studio-117453895-53ff3.appspot.com",
  messagingSenderId: "632587586931",
  appId: "1:632587586931:web:ea8cf536d555f4984",
  measurementId: "",
  databaseURL: "https://studio-117453895-53ff3-default-rtdb.firebaseio.com" // ← أضفها يدويًا
};