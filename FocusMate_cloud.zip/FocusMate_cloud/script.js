import { db } from "./firebase-config.js";
import { ref, push, onValue } from "https://www.gstatic.com/firebasejs/10.14.0/firebase-database.js";

const minutesDisplay = document.getElementById("minutes");
const secondsDisplay = document.getElementById("seconds");
const startBtn = document.getElementById("startBtn");
const resetBtn = document.getElementById("resetBtn");
const sessionsList = document.getElementById("sessionsList");

let timer;
let timeLeft = 25 * 60;
let running = false;

function updateDisplay() {
  const mins = Math.floor(timeLeft / 60);
  const secs = timeLeft % 60;
  minutesDisplay.textContent = String(mins).padStart(2, "0");
  secondsDisplay.textContent = String(secs).padStart(2, "0");
}

startBtn.onclick = () => {
  if (!running) {
    running = true;
    timer = setInterval(() => {
      timeLeft--;
      updateDisplay();
      if (timeLeft <= 0) {
        clearInterval(timer);
        running = false;
        saveSession();
        alert("🎉 Session complete!");
        timeLeft = 25 * 60;
        updateDisplay();
      }
    }, 1000);
  }
};

resetBtn.onclick = () => {
  clearInterval(timer);
  running = false;
  timeLeft = 25 * 60;
  updateDisplay();
};

function saveSession() {
  const sessionRef = ref(db, "sessions");
  const now = new Date();
  push(sessionRef, {
    user: "koussay",
    date: now.toISOString(),
    focusMinutes: 25
  });
}

function loadSessions() {
  const sessionRef = ref(db, "sessions");
  onValue(sessionRef, (snapshot) => {
    sessionsList.innerHTML = "";
    snapshot.forEach((child) => {
      const item = child.val();
      const li = document.createElement("li");
      li.textContent = `${item.date.split("T")[0]} - ${item.focusMinutes}min`;
      sessionsList.appendChild(li);
    });
  });
}

loadSessions();
updateDisplay();